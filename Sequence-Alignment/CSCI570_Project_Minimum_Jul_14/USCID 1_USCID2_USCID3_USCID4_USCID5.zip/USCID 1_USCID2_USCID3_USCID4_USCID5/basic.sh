#!/bin/bash
python3 basic.py "$1" "$2"
